@echo off
rem This project is intended to be opened/imported in IntelliJ IDEA with Gradle 9.x.
if exist "%~dp0gradle\wrapper\gradle-wrapper.jar" (
  java -classpath "%~dp0gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
  exit /b %errorlevel%
)
echo Gradle Wrapper JAR is not included. Open the project in IntelliJ IDEA and select a local Gradle 9.x installation.
exit /b 1
