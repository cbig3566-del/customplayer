package ru.example.playerjoinalert;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.Locale;
import java.util.regex.Pattern;

public class PlayerJoinAlertClient implements ClientModInitializer {
    public static final String MOD_ID = "player_join_alert";
    public static final Identifier ALERT_SOUND_ID = Identifier.of(MOD_ID, "alert");
    public static final SoundEvent ALERT_SOUND = SoundEvent.of(ALERT_SOUND_ID);

    @Override
    public void onInitializeClient() {
        AlertConfig.load();

        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!AlertConfig.get().enabled || AlertConfig.get().players.isEmpty()) return;

            String text = message.getString();
            if (!isJoinMessage(text)) return;

            for (String player : AlertConfig.get().players) {
                if (player == null || player.isBlank()) continue;
                if (containsPlayerName(text, player.trim())) {
                    playAlert();
                    break;
                }
            }
        });
    }

    private static boolean isJoinMessage(String text) {
        String lower = text.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
        return lower.contains("joined the game")
                || lower.contains("joined the server")
                || lower.contains("has joined the game")
                || lower.contains("has joined the server")
                || lower.contains("присоединился к игре")
                || lower.contains("присоединился к серверу")
                || lower.contains("присоединилась к игре")
                || lower.contains("присоединилась к серверу")
                || lower.contains("вошел в игру")
                || lower.contains("вошла в игру")
                || lower.contains("зашел в игру")
                || lower.contains("зашла в игру");
    }

    private static boolean containsPlayerName(String text, String player) {
        return Pattern.compile("(?i)(?:^|[^A-Za-z0-9_])" + Pattern.quote(player) + "(?:$|[^A-Za-z0-9_])")
                .matcher(text)
                .find();
    }

    public static void playAlert() {
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity player = client.player;
        if (player == null) return;

        player.playSoundToPlayer(
                ALERT_SOUND,
                SoundCategory.MASTER,
                AlertConfig.clamp(AlertConfig.get().volume),
                1.0f
        );
    }

    public static Text text(String key) {
        return Text.translatable(key);
    }
}
