package ru.example.playerjoinalert;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class AlertConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("player_join_alert.json");
    private static AlertConfig INSTANCE = new AlertConfig();

    public boolean enabled = true;
    public float volume = 1.0f;
    public List<String> players = new ArrayList<>();

    public static AlertConfig get() {
        return INSTANCE;
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                try (Reader reader = Files.newBufferedReader(FILE)) {
                    AlertConfig loaded = GSON.fromJson(reader, AlertConfig.class);
                    if (loaded != null) INSTANCE = loaded;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            INSTANCE = new AlertConfig();
        }
        if (INSTANCE.players == null) INSTANCE.players = new ArrayList<>();
        INSTANCE.volume = clamp(INSTANCE.volume);
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE)) {
                GSON.toJson(INSTANCE, writer);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static float clamp(float value) {
        return Math.max(0.0f, Math.min(10.0f, value));
    }
}
