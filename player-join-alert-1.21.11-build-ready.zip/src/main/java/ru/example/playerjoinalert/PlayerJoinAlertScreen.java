package ru.example.playerjoinalert;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class PlayerJoinAlertScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget playerBox;
    private TextFieldWidget removeBox;
    private TextFieldWidget volumeBox;
    private ButtonWidget toggleButton;

    public PlayerJoinAlertScreen(Screen parent) {
        super(Text.translatable("player_join_alert.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2;

        playerBox = new TextFieldWidget(textRenderer, cx - 155, 42, 220, 20,
                Text.translatable("player_join_alert.player"));
        playerBox.setPlaceholder(Text.translatable("player_join_alert.player_hint"));
        addDrawableChild(playerBox);

        addDrawableChild(ButtonWidget.builder(Text.translatable("player_join_alert.add"), button -> addPlayer())
                .dimensions(cx + 70, 42, 85, 20).build());

        volumeBox = new TextFieldWidget(textRenderer, cx - 155, 92, 70, 20,
                Text.translatable("player_join_alert.volume"));
        volumeBox.setText(String.valueOf(AlertConfig.get().volume));
        addDrawableChild(volumeBox);

        toggleButton = addDrawableChild(ButtonWidget.builder(toggleText(), button -> {
            AlertConfig.get().enabled = !AlertConfig.get().enabled;
            button.setMessage(toggleText());
            AlertConfig.save();
        }).dimensions(cx - 70, 92, 140, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.translatable("player_join_alert.test"), button -> {
            saveVolume();
            PlayerJoinAlertClient.playAlert();
        }).dimensions(cx + 75, 92, 80, 20).build());

        removeBox = new TextFieldWidget(textRenderer, cx - 155, 142, 220, 20,
                Text.translatable("player_join_alert.remove_player"));
        removeBox.setPlaceholder(Text.translatable("player_join_alert.remove_hint"));
        addDrawableChild(removeBox);

        addDrawableChild(ButtonWidget.builder(Text.translatable("player_join_alert.remove"), button -> removePlayer())
                .dimensions(cx + 70, 142, 85, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), button -> close())
                .dimensions(cx - 100, height - 28, 200, 20).build());
    }

    private Text toggleText() {
        return Text.translatable(AlertConfig.get().enabled
                ? "player_join_alert.enabled"
                : "player_join_alert.disabled");
    }

    private void addPlayer() {
        String player = playerBox.getText().trim();
        if (player.isEmpty()) return;

        if (!AlertConfig.get().players.contains(player)) {
            AlertConfig.get().players.add(player);
            AlertConfig.save();
        }
        playerBox.setText("");
    }

    private void removePlayer() {
        String player = removeBox.getText().trim();
        if (player.isEmpty()) return;
        AlertConfig.get().players.removeIf(p -> p.equalsIgnoreCase(player));
        AlertConfig.save();
        removeBox.setText("");
    }

    private void saveVolume() {
        try {
            AlertConfig.get().volume = AlertConfig.clamp(Float.parseFloat(volumeBox.getText().trim()));
        } catch (NumberFormatException ignored) {
            AlertConfig.get().volume = 1.0f;
            volumeBox.setText("1.0");
        }
        AlertConfig.save();
    }

    @Override
    public void close() {
        saveVolume();
        MinecraftClient.getInstance().setScreen(parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 15, 0xFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.translatable("player_join_alert.player"), width / 2 - 155, 28, 0xAAAAAA);
        context.drawTextWithShadow(textRenderer, Text.translatable("player_join_alert.volume"), width / 2 - 155, 78, 0xAAAAAA);
        context.drawTextWithShadow(textRenderer, Text.translatable("player_join_alert.remove_player"), width / 2 - 155, 128, 0xAAAAAA);

        int y = 178;
        context.drawTextWithShadow(textRenderer, Text.translatable("player_join_alert.current_players"), width / 2 - 155, y, 0xAAAAAA);
        y += 18;
        for (String player : AlertConfig.get().players) {
            context.drawTextWithShadow(textRenderer, "• " + player, width / 2 - 145, y, 0xFFFFFF);
            y += 16;
            if (y > height - 50) break;
        }

        context.drawTextWithShadow(textRenderer, Text.translatable("player_join_alert.sound_info"), width / 2 - 155, height - 44, 0xAAAAAA);
        super.render(context, mouseX, mouseY, delta);
    }
}
