# Player Join Alert — Minecraft 1.21.11

Client-side Fabric mod that plays `assets/player_join_alert/sounds/alert.ogg` when a selected player joins via a server game message.

## Versions
- Minecraft 1.21.11
- Fabric Loader 0.19.2
- Fabric API 0.141.6+1.21.11
- Yarn 1.21.11+build.6
- Fabric Loom 1.14.10
- Mod Menu 17.0.1-beta.1
- Java 21

## Browser/GitHub build
The repository workflow can use Gradle 9.2.1 directly, so the missing local Gradle wrapper JAR is not required for GitHub Actions.

## Sound
Replace:
`src/main/resources/assets/player_join_alert/sounds/alert.ogg`
with your own OGG file, keeping the name `alert.ogg`.

## Important
This version listens to Fabric's client GAME-message event. It recognizes common English and Russian join-message phrases. If a server completely changes/blocks its join message, a packet/protocol-specific implementation may be needed.
