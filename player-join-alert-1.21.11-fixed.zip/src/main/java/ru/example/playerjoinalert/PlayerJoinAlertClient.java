package ru.example.playerjoinalert;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

import java.util.Locale;
import java.util.regex.Pattern;

public class PlayerJoinAlertClient implements ClientModInitializer {
    public static final String MOD_ID = "player_join_alert";
    public static final ResourceLocation ALERT_SOUND_ID = ResourceLocation.fromNamespaceAndPath(MOD_ID, "alert");

    @Override
    public void onInitializeClient() {
        AlertConfig.load();

        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!AlertConfig.get().enabled || AlertConfig.get().players.isEmpty()) return;

            String text = message.getString();
            if (!isJoinMessage(text)) return;

            for (String player : AlertConfig.get().players) {
                if (player == null || player.isBlank()) continue;
                if (containsPlayerName(text, player.trim())) {
                    playAlert();
                    break;
                }
            }
        });
    }

    private static boolean isJoinMessage(String text) {
        String lower = text.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
        return lower.contains("joined the game")
                || lower.contains("joined the server")
                || lower.contains("has joined the game")
                || lower.contains("has joined the server")
                || lower.contains("присоединился к игре")
                || lower.contains("присоединился к серверу")
                || lower.contains("присоединилась к игре")
                || lower.contains("присоединилась к серверу")
                || lower.contains("вошел в игру")
                || lower.contains("вошла в игру")
                || lower.contains("зашел в игру")
                || lower.contains("зашла в игру");
    }

    private static boolean containsPlayerName(String text, String player) {
        return Pattern.compile("(?i)(?:^|[^A-Za-z0-9_])" + Pattern.quote(player) + "(?:$|[^A-Za-z0-9_])")
                .matcher(text)
                .find();
    }

    public static void playAlert() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        SoundEvent sound = SoundEvent.createVariableRangeEvent(ALERT_SOUND_ID);
        mc.player.playSoundToPlayer(sound, SoundSource.MASTER, AlertConfig.clamp(AlertConfig.get().volume), 1.0f);
    }

    public static Component text(String key) {
        return Component.translatable(key);
    }
}
