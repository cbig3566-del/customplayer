package ru.example.playerjoinalert;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class PlayerJoinAlertScreen extends Screen {
    private final Screen parent;
    private EditBox playerBox;
    private EditBox volumeBox;
    private final List<Button> rowButtons = new ArrayList<>();

    public PlayerJoinAlertScreen(Screen parent) {
        super(Component.translatable("player_join_alert.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int y = 40;

        playerBox = new EditBox(font, cx - 155, y, 220, 20, Component.translatable("player_join_alert.player"));
        playerBox.setHint(Component.translatable("player_join_alert.player_hint"));
        addRenderableWidget(playerBox);

        addRenderableWidget(Button.builder(Component.translatable("player_join_alert.add"), b -> addPlayer())
                .bounds(cx + 70, y, 85, 20).build());

        volumeBox = new EditBox(font, cx - 155, y + 48, 70, 20, Component.translatable("player_join_alert.volume"));
        volumeBox.setValue(String.valueOf(AlertConfig.get().volume));
        addRenderableWidget(volumeBox);

        addRenderableWidget(Button.builder(buttonText(), b -> {
            AlertConfig.get().enabled = !AlertConfig.get().enabled;
            b.setMessage(buttonText());
            AlertConfig.save();
        }).bounds(cx - 70, y + 48, 140, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("player_join_alert.test"), b -> {
            saveVolume();
            PlayerJoinAlertClient.playAlert();
        }).bounds(cx + 75, y + 48, 80, 20).build());

        rebuildRows(y + 82);

        addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> close())
                .bounds(cx - 100, height - 28, 200, 20).build());
    }

    private Component buttonText() {
        return Component.translatable(AlertConfig.get().enabled
                ? "player_join_alert.enabled"
                : "player_join_alert.disabled");
    }

    private void addPlayer() {
        String player = playerBox.getValue().trim();
        if (player.isEmpty()) return;

        if (!AlertConfig.get().players.contains(player)) {
            AlertConfig.get().players.add(player);
            AlertConfig.save();
        }

        playerBox.setValue("");
        rebuildRows(122);
    }

    private void saveVolume() {
        try {
            AlertConfig.get().volume = AlertConfig.clamp(Float.parseFloat(volumeBox.getValue().trim()));
        } catch (NumberFormatException ignored) {
            AlertConfig.get().volume = 1.0f;
            volumeBox.setValue("1.0");
        }
        AlertConfig.save();
    }

    private void rebuildRows(int startY) {
        for (Button b : rowButtons) removeWidget(b);
        rowButtons.clear();

        int cx = width / 2;
        int y = startY;
        for (int i = 0; i < AlertConfig.get().players.size(); i++) {
            final int index = i;
            String player = AlertConfig.get().players.get(i);

            Button row = Button.builder(Component.literal("👤 " + player), b -> {})
                    .bounds(cx - 155, y, 235, 20).build();
            Button remove = Button.builder(Component.translatable("player_join_alert.remove"), b -> {
                if (index < AlertConfig.get().players.size()) {
                    AlertConfig.get().players.remove(index);
                    AlertConfig.save();
                    rebuildRows(startY);
                }
            }).bounds(cx + 85, y, 70, 20).build();

            addRenderableWidget(row);
            addRenderableWidget(remove);
            rowButtons.add(row);
            rowButtons.add(remove);
            y += 24;

            if (y > height - 45) break;
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        graphics.drawCenteredString(font, title, width / 2, 15, 0xFFFFFF);
        graphics.drawString(font, Component.translatable("player_join_alert.player"), width / 2 - 155, 28, 0xAAAAAA);
        graphics.drawString(font, Component.translatable("player_join_alert.volume"), width / 2 - 155, 78, 0xAAAAAA);
        graphics.drawString(font, Component.translatable("player_join_alert.sound_info"), width / 2 - 155, height - 44, 0xAAAAAA);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public void onClose() {
        saveVolume();
        Minecraft.getInstance().setScreen(parent);
    }
}
