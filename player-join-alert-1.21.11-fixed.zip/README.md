# Player Join Alert — Minecraft 1.21.11 / Fabric

Мод работает на клиенте. Он слушает игровые сообщения от сервера и, если сообщение похоже на сообщение о входе, проверяет список выбранных ников. При совпадении проигрывает `alert.ogg`.

## Версии
- Minecraft 1.21.11
- Fabric Loader 0.19.2
- Fabric API 0.141.6+1.21.11
- Mod Menu 17.0.1-beta.1
- Java 21+

## Звук
Файл по умолчанию:
`src/main/resources/assets/player_join_alert/sounds/alert.ogg`

Замени его своим OGG-файлом. Имя оставь `alert.ogg`.

## Сборка в IntelliJ IDEA
1. Установи JDK 21.
2. Открой папку проекта в IntelliJ IDEA.
3. В настройках Gradle укажи Gradle JVM = Java 21.
4. Для сборки нужен Gradle 9.x. Можно выбрать локальную установку Gradle в IntelliJ.
5. Выполни задачу `build`.
6. Готовый мод будет в `build/libs/player-join-alert-1.0.1.jar`.

## Использование
Mod Menu -> Player Join Alert.
Добавь ники, настрой громкость и нажми Test.

Конфиг хранится в `.minecraft/config/player_join_alert.json`.
